package com.crud.repository;

//package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface vendorRepository extends JpaRepository< vendor,Long>{
    
}